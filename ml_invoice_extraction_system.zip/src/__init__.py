"""
ML-Based Invoice Data Extraction System
Core Package
"""

__version__ = "1.0.0"
